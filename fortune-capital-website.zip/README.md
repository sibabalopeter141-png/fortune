# Fortune Capital Holdings Website

This is the official single-page website for Fortune Capital Holdings (Pty) Ltd.

## Company Description

Fortune Capital Holdings is a private investment firm based in Cape Town that focuses on acquiring small to medium-sized logistics businesses. We specialize in deal structuring using seller financing, bank loans, and government funding.

## Contact

- 📧 Email: fortunecapital203@gmail.com  
- 📞 Phone: 073 355 4666

## How to Use

1. Clone this repo
2. Open `index.html` in any browser
3. Deploy to GitHub Pages or Netlify
